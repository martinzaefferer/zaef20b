getProblem <- function(dime,inst,func){
	suite_name="bbob"
	py_run_string("import cocoex")
	py_run_string("from cocoex import Suite")
	py_run_string(paste("suite_options='dimensions: ",paste(dime,collapse = ","), " ",
											"function_indices: ",paste(func,collapse = ",")," ",
											"instance_indices: ",paste(inst,collapse = ","),"'",sep=""))
	py_run_string("suite_instance = ''")
	py_run_string(paste("suite_name = '",suite_name,"'",sep=""))
	py_run_string("suite = Suite(suite_name, suite_instance, suite_options)")
	py_run_string("problem = suite.get_problem(0)")
	lower <- py$problem$lower_bounds
	upper <- py$problem$upper_bounds
	problem <- py$problem
	return(list(lower=lower,upper=upper,problem=problem))
}