convergencePlotBBOB <- function(at){
  require(dplyr)
  at$y <- at$y - min(at$y) + 1

  at = at %>% group_by(iteration, nDim) %>%  mutate(upper = summary(y)[[5]]) %>%
    mutate(lower = summary(y)[[2]]) %>% mutate(med = summary(y)[[3]]) %>% mutate(mmin = mean(y))

  ggplot(at, aes(x=iteration,y=med))  + geom_line() +
    geom_ribbon(aes(ymin=lower, ymax=upper), alpha=0.1) +
    facet_grid(rows = vars(),cols = vars(nDim), scales = "free_x") +
    labs(x="iteration", y = "y") + scale_y_continuous(trans = 'log10')
}
