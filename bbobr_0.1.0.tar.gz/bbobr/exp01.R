require(SPOT)
require(bbobr)

solverSPOT <- function(fun,lower,upper, parameterList){
  ndim <- length(lower)
  spotControl <- list(
    funEvals = 100,
    optimizer = optimDE,
    optimizerControl = list(
      funEvals=200*ndim,
      populationSize=10*ndim
    ),
    model = buildKriging,
    modelControl=list(
      target="ei",
      lambdaLower=-6,
      lambdaUpper=-4,
      thetaLower=1e-6,
      thetaUpper=1e2,
      optimizeP=TRUE,
      reinterpolate=TRUE,
      useLambda=TRUE,
      algTheta=optimDE
    ),
    design = designLHD,
    designControl = list(size=9*ndim)# 5
  )
  ########target function wrapper for SPOT
  tfun <- function(x){
    apply(x,1,fun)
  }
  res <- optimDE(fun = tfun ,lower= lower, upper=upper)
  #res <- spot(fun = tfun ,lower= lower, upper=upper, control = spotControl)
  return(res)
}

unlink("exdata", recursive = T)
runCOCO(solverSPOT,current_batch = 1,number_of_batches = 1,dimensions=c(2,3), instances = c(1:2), functions = c(1:3))
startBatches(nPerBatch = 1,solverSPOT,dimensions=c(2), instances = c(1:2), solver_name = "testAlg1")
df <- readBBOB("exdata")
df <- applyFrNamingScheme(df)
convergencePlotBBOB(df)

