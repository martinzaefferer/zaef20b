library(SPOT)
library(bbobr)
library(reticulate)

args = c(1,1,1,2,1)

### Recieve Seed + Instance
instance <- as.numeric(args[1])
seed <- as.numeric(args[2])
set.seed(seed)

### BUDGET
TOTAL_FUN_BUDGET = 102

### Recieve Function ID
### 1-24 bbob functions
funID <- as.numeric(args[3])

### NDIM
nDim <- as.numeric(args[4])

###### Algorithm Setup:
######
algoID <- as.numeric(args[5])

#################
solver <- function(fun,lower,upper,solverParameterList){
  ########target function wrapper
  #tfun <- function(x){
  #    cat(paste("time=",Sys.time(),"samples=",nrow(x),"\n"), file = paste("timeRes/SPOT",paste(args,collapse="_"),sep="_"), append = T)
  #    fun(x)
  #}

  popSize <- 6

  cma<-import("cma")
  initial <- matrix(runif(length(lower),lower,upper), nrow = 1, ncol = length(lower))
  properties = list('bounds'= c(lower[1], upper[1]), 'popsize'= popSize)
  maxiter = floor(TOTAL_FUN_BUDGET/popSize) - 1
  es<-cma$CMAEvolutionStrategy(initial, 0.5, properties)
  while(es$countiter<=maxiter){
    x<-es$ask()
    xp<-r_to_py(x)
    es$tell(xp,sapply(x,fun))
  }
  return(es$result$fbest)
}

#runCOCO(solver,current_batch = 1,number_of_batches = 1,dimensions=nDim, instances = instance,
#        functions = funID,solver_name = paste("CMAES",paste(args,collapse="_"),sep="_"))

sFun <- function(x){
  return(sum(x^2))
}

wrappedSphere <- wrapToBBOBFunction(sFun,functionID = 1,nDim = 5, instanceID = 1,knownFunctionOptimum = 0,
                                    algoID = paste("CMAES",paste(args,collapse="_"),sep="_"),experimentPath = "ownBB2", printX = T, saveIndividuals = F)

solver(wrappedSphere, c(-5,-5,-5,-5,-5), c(5,5,5,5,5), list())

df <- readBBOB("ownBB2")
